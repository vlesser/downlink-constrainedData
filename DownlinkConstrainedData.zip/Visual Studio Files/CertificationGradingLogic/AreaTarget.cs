﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CertificationGradingLogic
{
    public class Target
    {
        public string TargetName { get; set; }
        public string AreaSize { get; set; }
        public double Bearing { get; set; }
        public double Lat { get; set; }
        public double Lon { get; set; }
    }
}
