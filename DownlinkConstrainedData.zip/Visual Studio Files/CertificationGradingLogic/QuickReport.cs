﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CertificationGradingLogic
{
    public class QuickReport
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public string Style { get; set; }
        public string Instance { get; set; }
        public string AccessInstance { get; set; }
    }
}
