﻿using AGI.STKObjects;
using AGI.Ui.Application;
using System;
using System.Collections.Generic;
using AGI.STKUtil;
using System.IO;
using System.IO.Compression;
using System.Windows.Forms;

namespace CertificationGradingLogic
{
    public class StkGrading
    {
        private AgUiApplication uiApp;
        private AgStkObjectRoot m_root;
        private string m_scenarioPath;
        private IAgScenario m_scenario;
        private IAgStkObject OLESS;
        private IAgStkObject SOF;
        private IAgStkObject Amsterdam;
        private IAgStkObject Ascension;
        private IAgStkObject Easter;
        private IAgStkObject Seychelles;
        private IAgStkObject Shanghai;
        private IAgStkObject Shemya;
        private IAgStkObject Sundarbans;
        private IAgStkObject Wake;
        private IAgStkObject WideView_120;
        private IAgStkObject WideView_130;
        private IAgStkObject WideView_140;
        public Boolean fixedConstraintViolated = false;
        public Boolean noPenaltyfixedConstraintViolated = false;
        public Boolean kanSatConstraintViolated = false;
        public Boolean launchConstraintViolated = false;
        public List<double> OLESSSatSatOrbitalElements;

        public double[] totalCoverage = new double[24];
        public int[] dailyAccessCheck = new int[8];
        
        public Array wideView130;
        public Array wideView120;
        public Array wideViewList140;
        public Array satelliteAccess;
        public Array FirstStartTime;


        public string message = "";

        private List<TestQuestion> m_questions;

        public StkGrading(string scenarioPath)
        {
            m_questions = new List<TestQuestion>();

            uiApp = new AgUiApplication();
            uiApp.LoadPersonality("STK");
            uiApp.Visible = true;
            m_root = uiApp.Personality2 as AgStkObjectRoot;
            if (scenarioPath.EndsWith(".zip"))
            {
                string tempPath = Path.GetTempPath();
                string zipPath = scenarioPath;

                string folder = Path.GetFileNameWithoutExtension(scenarioPath);
                string extractedPath = Path.Combine(tempPath, folder);

                if (Directory.Exists(extractedPath))
                {
                    Directory.Delete(extractedPath, true);
                }
                ZipFile.ExtractToDirectory(zipPath, tempPath);

                string[] filesSC = Directory.GetFiles(extractedPath, "*.sc");
                string[] filesVDF = Directory.GetFiles(extractedPath, "*.vdf");

                if (filesSC.Length > 0)
                {
                    m_root.LoadScenario(filesSC[0]);
                }
                else if (filesVDF.Length > 0)
                {
                    m_root.LoadVDF(filesVDF[0], "");
                }
            }

            else if (scenarioPath.EndsWith(".sc"))
            {
                m_root.LoadScenario(scenarioPath);
            }
            else if (scenarioPath.EndsWith(".vdf"))
            {
                m_root.LoadVDF(scenarioPath, "");
            }

            m_scenario = m_root.CurrentScenario as IAgScenario;
            IAgExecCmdResult directory = m_root.ExecuteCommand("GetDirectory / Scenario");
            m_scenarioPath = directory[0].ToString();

        }

        //Reset global variables if test is rerun
        private void reset()
        {
            m_questions = new List<TestQuestion>();
            fixedConstraintViolated = false;
            noPenaltyfixedConstraintViolated = false;
            kanSatConstraintViolated = false;
            launchConstraintViolated = false;
            SOF = null;
            OLESS = null;
            Amsterdam = null;
            Ascension = null;
            Easter = null;
            Seychelles = null;
            Shanghai = null;
            Shemya = null;
            Sundarbans = null;
            Wake = null;
            WideView_120 = null;
            WideView_130 = null;
            WideView_140 = null;

        }

        //Test if the scenario start time is correct and change if incorrect
        private void startTime()
        {
            m_root.UnitPreferences.SetCurrentUnit("DateFormat", "UTCG");

            TestQuestion question = new TestQuestion();
            question.Objective = "Scenario Start Time";
            question.RequiredConstraint = "1 May 2020 00:00:00.000";
            question.UsedConstraint = m_scenario.StartTime;
            question.ConstraintType = "Fixed Constraint";


            if (question.RequiredConstraint == question.UsedConstraint)
            {
                question.Violations = "No Violations";
            }
            else
            {
                question.Violations = "Violated";
                m_scenario.StartTime = "1 May 2020 00:00:00.000 ";
                fixedConstraintViolated = true;
            }
            m_questions.Add(question);
        }

        //Test if the scenario stop time is correct and change if incorrect
        private void stopTime()
        {
            m_root.UnitPreferences.SetCurrentUnit("DateFormat", "UTCG");

            TestQuestion question = new TestQuestion();
            question.Objective = "Scenario Stop Time";
            question.RequiredConstraint = "8 May 2020 00:00:00.000";
            question.UsedConstraint = m_scenario.StopTime;
            question.ConstraintType = "Fixed Constraint";


            if (question.RequiredConstraint == question.UsedConstraint)
            {
                question.Violations = "No Violations";
            }
            else
            {
                question.Violations = "Violated";
                m_scenario.StopTime = "8 May 2020 00:00:00";
                fixedConstraintViolated = true;
            }
            m_questions.Add(question);
        }

        //Get orbital elements for given satellite
        private List<double> GetOrbitalElements(IAgStkObject mySat)
        {
            m_root.UnitPreferences.SetCurrentUnit("Time", "min");
            IAgOrbitStateClassical keplerian;
            keplerian = ((IAgOrbitStateClassical)((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).InitialState.Representation.ConvertTo(AgEOrbitStateType.eOrbitStateClassical));


            double inc = keplerian.Orientation.Inclination;
            double ArgOfPerigee = keplerian.Orientation.ArgOfPerigee; //IAgClassicalOrientation

            double RAAN = ((IAgOrientationAscNodeRAAN)keplerian.Orientation.AscNode).Value;

            double apogee = ((IAgClassicalSizeShapeAltitude)keplerian.SizeShape).ApogeeAltitude;
            double perigee = ((IAgClassicalSizeShapeAltitude)keplerian.SizeShape).PerigeeAltitude;

            double ta = ((IAgClassicalLocationTrueAnomaly)keplerian.Location).Value;

            keplerian.SizeShapeType = AgEClassicalSizeShape.eSizeShapePeriod;
            ((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).InitialState.Representation.Assign(keplerian);
            double period = ((IAgClassicalSizeShapePeriod)keplerian.SizeShape).Period;

            List<double> orbitalElements = new List<double>();
            //Pull orbital elements data provider
            IAgDataProviderGroup dpInfo1 = OLESS.DataProviders["Classical Elements"] as IAgDataProviderGroup;
            IAgDataPrvTimeVar dpInfo2 = dpInfo1.Group["ICRF"] as IAgDataPrvTimeVar;
            IAgDrResult resInfo = dpInfo2.ExecSingle("1 May 2020 00:00:00.000 ");

            //Add orbital elements to list
            orbitalElements.Add(apogee);
            orbitalElements.Add(perigee);
            orbitalElements.Add(inc);
            orbitalElements.Add(ArgOfPerigee);
            orbitalElements.Add(RAAN);
            orbitalElements.Add(ta);

            keplerian.Epoch = "1 Jan 2016 05:00:00.000";
            ((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).InitialState.Representation.Assign(keplerian);
            ((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).Propagate();

            return orbitalElements;

        }


        private void objectCheck()
        {

            if (SOF == null)
            {
                message = " SOF Object does not exist, cannot grade.";
                MessageBox.Show(message);

            }
            if (OLESS == null)
            {
                message = "OLESS Object does not exist, cannot grade.";
                MessageBox.Show(message);
            }
            if (Amsterdam == null)
            {
                message = " Amsterdam Object does not exist, cannot grade.";
                MessageBox.Show(message);
            }
            if (Ascension == null)
            {
                message = "Ascension Object does not exist, cannot grade.";
                MessageBox.Show(message);
            }
            if (Easter == null)
            {
                message = "Easter Object does not exist, cannot grade.";
                MessageBox.Show(message);
            }
            if (Seychelles == null)
            {
                message = "Seychelles Object does not exist, cannot grade.";
                MessageBox.Show(message);
            }
            if (Shanghai == null)
            {
                message = "Shanghai Object does not exist, cannot grade.";
                MessageBox.Show(message);
            }
            if (Shemya == null)
            {
                message = "Shemya Object does not exist, cannot grade.";
                MessageBox.Show(message);
            }

            if (Sundarbans == null)
            {
                message = "Sundarbans Object does not exist, cannot grade.";
                MessageBox.Show(message);

            }
            if (Wake == null)
            {
                    message = "Wake Object does not exist, cannot grade.";
                    MessageBox.Show(message);

            }
            
        }

            private IAgStkObject stkObjectInScenario(string objectName, string objectClass)
            {
                IAgStkObject returnObject = null;
                List<IAgStkObject> stkObjects = new List<IAgStkObject>();

                for (int i = 0; i < ((IAgStkObject)m_scenario).Children.Count; i++)
                {
                    IAgStkObject stkObject = ((IAgStkObject)m_scenario).Children[i] as IAgStkObject;
                    if (stkObject.ClassName == objectClass)
                    {
                        stkObjects.Add(stkObject);
                    }
                }

                if (stkObjects.Count == 1)
                {
                    returnObject = stkObjects[0];
                }
                else if (stkObjects.Count > 1)
                {
                    foreach (IAgStkObject obj in stkObjects)
                    {
                        //if (obj.InstanceName.ToLower().StartsWith(objectName.Substring(0, 3).ToLower()))
                        if (obj.InstanceName.Equals(objectName))
                        {
                            returnObject = obj;
                        }
                    }
                }
                return returnObject;
            }

            private IAgStkObject stkSensorExists(string objectName, IAgStkObject stkObject)
            {

                IAgStkObject stkSensor = null;


                if (stkObject != null)
                {
                    IAgStkObjectElementCollection sensors = stkObject.Children.GetElements(AgESTKObjectType.eSensor) as IAgStkObjectElementCollection;
                    if (sensors.Count > 0)
                    {

                        foreach (IAgStkObject sensor in sensors)
                        {
                            if (sensor.InstanceName == objectName)
                            {
                                stkSensor = sensor;
                            }
                        }
                    }
                }



                return stkSensor;
            } 

        // Test if satellite propagator is correct and change to propagator type J2pertubation if incorrect
        private void propagatorConstraint(IAgStkObject mySat)
        {


            TestQuestion question = new TestQuestion();
            question.Objective = "Satellite Propagator";

            question.RequiredConstraint = "J2Perturbation" + " (" + mySat.InstanceName.ToString() + ")"; ;
            question.ConstraintType = "Fixed Constraint";

            if (mySat != null)
            {
                if (((IAgSatellite)mySat).PropagatorType == AgEVePropagatorType.ePropagatorJ2Perturbation)
                {
                    question.UsedConstraint = "J2Perturbation";
                    question.Violations = "No Violations";
                }
                else
                {
                    question.UsedConstraint = Convert.ToString(((IAgSatellite)mySat).PropagatorType);

                    ((IAgSatellite)mySat).SetPropagatorType(AgEVePropagatorType.ePropagatorJ2Perturbation);
                    ((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).Propagate();

                    question.Violations = "Violated";
                    fixedConstraintViolated = true;
                }
                m_questions.Add(question);
            }

        }

        //Check time step and change the step size if neccessary 
        private void timeStepConstraint(IAgStkObject mySat)
        {

            m_root.UnitPreferences.SetCurrentUnit("Time", "sec");


            TestQuestion question = new TestQuestion();
            question.Objective = "Time Step";
            question.ConstraintType = "Fixed Constraint";
            question.RequiredConstraint = "60 sec" + " (" + mySat.InstanceName.ToString() + ")"; ;


            if (mySat != null)
            {
                if (((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).Step == 60)
                {
                    question.Violations = "No Violations";
                    question.UsedConstraint = "60 sec";
                }
                else
                {
                    question.UsedConstraint = Convert.ToString(((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).Step) + " sec";
                    ((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).Step = 60;
                    question.Violations = "Violated";
                    fixedConstraintViolated = true;
                }
            }

            m_questions.Add(question);

        }

        //Check ground site latitude and change latitude if neccessary
        private void facLatCheck(IAgStkObject myFac, String requiredConstraint, double requiredConstraintValue)
        {
            m_root.UnitPreferences.SetCurrentUnit("Angle", "deg");
            m_root.UnitPreferences.SetCurrentUnit("Distance", "km");

            object lat = 0, lon = 0;
            double alt = 0;
            int typeInd = 0;

            ((IAgFacility)myFac).Position.QueryPlanetodetic(out lat, out lon, out alt);

            
            
            double value = Math.Round(Convert.ToDouble(lat), 2);
            double roundedConstraint = Math.Round(requiredConstraintValue, 2);

            TestQuestion question = new TestQuestion();
            question.Objective = myFac.InstanceName.ToString() + " Latitude";
            question.ConstraintType = "Fixed Constraint";
            question.RequiredConstraint = requiredConstraint;

            question.UsedConstraint = Convert.ToString(value + " deg");

            if (myFac != null)
            {

                if (value == roundedConstraint)
                {
                    question.Violations = "No Violations";
                }
                else
                {
                    ((IAgFacility)myFac).Position.AssignGeodetic(requiredConstraintValue, lon, alt);
                    question.Violations = "Violated";
                    fixedConstraintViolated = true;
                }


            }

            m_questions.Add(question);
        }

        //Check ground site longitude and change longitude if neccessary 
        private void facLonCheck(IAgStkObject myFac, String requiredConstraint, double requiredConstraintValue)
        {
            m_root.UnitPreferences.SetCurrentUnit("Angle", "deg");
            m_root.UnitPreferences.SetCurrentUnit("Distance", "km");

            object lat = 0, lon = 0;
            double alt = 0;
            int typeInd = 0;

            ((IAgFacility)myFac).Position.QueryPlanetodetic(out lat, out lon, out alt);


            double value = Math.Round(Convert.ToDouble(lon), 2);
            double roundedConstraint = Math.Round(requiredConstraintValue,2);

            TestQuestion question = new TestQuestion();
            question.Objective = myFac.InstanceName.ToString() + " Longitude";
            question.ConstraintType = "Fixed Constraint";
            question.RequiredConstraint = requiredConstraint;

            question.UsedConstraint = Convert.ToString(value + " deg");

            if (myFac != null)
            {

                if (value == roundedConstraint)
                {
                    question.Violations = "No Violations";
                }
                else
                {
                    ((IAgFacility)myFac).Position.AssignGeodetic(lat, requiredConstraintValue, alt);
                    question.Violations = "No Violations";
                    fixedConstraintViolated = true;

                }


            }

            m_questions.Add(question);
        }

        //Check ground site longitude and change longitude if neccessary 
        private void ATLonCheck(IAgStkObject myTarget, String requiredConstraint, double requiredConstraintValue)
        {
            m_root.UnitPreferences.SetCurrentUnit("Angle", "deg");
            m_root.UnitPreferences.SetCurrentUnit("Distance", "km");

            object lat = 0, lon = 0;
            double alt = 0;
            int typeInd = 0;

            ((IAgTarget)myTarget).Position.QueryPlanetodetic(out lat, out lon, out alt);


            double value = Math.Round(Convert.ToDouble(lon), 2);
            double roundedConstraint = Math.Round(requiredConstraintValue, 2);

            TestQuestion question = new TestQuestion();
            question.Objective = myTarget.InstanceName.ToString() + " Longitude";
            question.ConstraintType = "Fixed Constraint";
            question.RequiredConstraint = requiredConstraint;

            question.UsedConstraint = Convert.ToString(value + " deg");

            if (myTarget != null)
            {

                if (value == roundedConstraint)
                {
                    question.Violations = "No Violations";
                }
                else
                {
                    ((IAgTarget)myTarget).Position.AssignGeodetic(lat, requiredConstraintValue, alt);
                    question.Violations = "Violated";
                    fixedConstraintViolated = true;

                }


            }

            m_questions.Add(question);
        }

        //Check ground site latitude and change latitude if neccessary
        private void ATLatCheck(IAgStkObject myTarget, String requiredConstraint, double requiredConstraintValue)
        {
            m_root.UnitPreferences.SetCurrentUnit("Angle", "deg");
            m_root.UnitPreferences.SetCurrentUnit("Distance", "km");

            object lat = 0, lon = 0;
            double alt = 0;
            int typeInd = 0;

            ((IAgTarget)myTarget).Position.QueryPlanetodetic(out lat, out lon, out alt);



            double value = Math.Round(Convert.ToDouble(lat), 2);
            double roundedConstraint = Math.Round(requiredConstraintValue, 2);

            TestQuestion question = new TestQuestion();
            question.Objective = myTarget.InstanceName.ToString() + " Latitude";
            question.ConstraintType = "Fixed Constraint";
            question.RequiredConstraint = requiredConstraint;

            question.UsedConstraint = Convert.ToString(value + " deg");

            if (myTarget != null)
            {

                if (value == roundedConstraint)
                {
                    question.Violations = "No Violations";
                }
                else
                {
                    ((IAgTarget)myTarget).Position.AssignGeodetic(requiredConstraintValue, lon, alt);
                    question.Violations = "Violated";
                    fixedConstraintViolated = true;
                }


            }

            m_questions.Add(question);
        }

        //Check ground site altitude and change if neccessary 
        private void ATAltCheck(IAgStkObject myTarget, String requiredConstraint, double requiredConstraintValue)
        {
            m_root.UnitPreferences.SetCurrentUnit("Angle", "deg");
            m_root.UnitPreferences.SetCurrentUnit("Distance", "m");

            object lat = 0, lon = 0;
            double alt = 0;

            ((IAgTarget)myTarget).Position.QueryPlanetodetic(out lat, out lon, out alt);

            double value = Math.Round(alt, 4);

            TestQuestion question = new TestQuestion();
            question.Objective = myTarget.InstanceName.ToString() + "Altitude";
            question.ConstraintType = "Fixed Constraint";
            question.RequiredConstraint = requiredConstraint;

            question.UsedConstraint = Convert.ToString(value + " m");

            if (myTarget != null)
            {

                if (value == Math.Round(requiredConstraintValue, 5))
                {
                    question.Violations = "No Violations";
                }
                else
                {
                    ((IAgTarget)myTarget).Position.AssignGeodetic(lat, lon, requiredConstraintValue);
                    question.Violations = "Violated";
                    fixedConstraintViolated = true;
                }


            }

            m_questions.Add(question);
            m_root.UnitPreferences.SetCurrentUnit("Distance", "km");
        }

        //Check ground site altitude and change if neccessary 
        private void facAltCheck(IAgStkObject myFac, String requiredConstraint, double requiredConstraintValue)
        {
            m_root.UnitPreferences.SetCurrentUnit("Angle", "deg");
            m_root.UnitPreferences.SetCurrentUnit("Distance", "m");

            object lat = 0, lon = 0;
            double alt = 0;

            ((IAgFacility)myFac).Position.QueryPlanetodetic(out lat, out lon, out alt);

            double value = Math.Round(alt, 4);

            TestQuestion question = new TestQuestion();
            question.Objective = myFac.InstanceName.ToString() + "Altitude";
            question.ConstraintType = "Fixed Constraint";
            question.RequiredConstraint = requiredConstraint;

            question.UsedConstraint = Convert.ToString(value + " m");

            if (myFac != null)
            {

                if (value == Math.Round(requiredConstraintValue, 5))
                {
                    question.Violations = "No Violations";
                }
                else
                {
                    ((IAgFacility)myFac).Position.AssignGeodetic(lat, lon, requiredConstraintValue);
                    question.Violations = "Violated";
                    fixedConstraintViolated = true;
                }


            }

            m_questions.Add(question);
            m_root.UnitPreferences.SetCurrentUnit("Distance", "km");
        }

        //Check perigee and change to minimum value if too low
        private void perigeeCheck(IAgStkObject mySat, String requiredConstraint, double requiredConstraintValue, double requiredConstraintTestValue)
        {
            m_root.UnitPreferences.SetCurrentUnit("Distance", "km");

            IAgOrbitStateClassical keplerian;
            keplerian = ((IAgOrbitStateClassical)((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).InitialState.Representation.ConvertTo(AgEOrbitStateType.eOrbitStateClassical));
            keplerian.SizeShapeType = AgEClassicalSizeShape.eSizeShapeAltitude;
            ((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).InitialState.Representation.Assign(keplerian);

            double apogee = ((IAgClassicalSizeShapeAltitude)((IAgOrbitStateClassical)((IAgVePropagatorJ2Perturbation)
                ((IAgSatellite)mySat).Propagator).InitialState.Representation.ConvertTo(AgEOrbitStateType.eOrbitStateClassical)).SizeShape).ApogeeAltitude;
            double apogeeRound = Math.Round(apogee, 3);
            double perigee = ((IAgClassicalSizeShapeAltitude)((IAgOrbitStateClassical)((IAgVePropagatorJ2Perturbation)
                ((IAgSatellite)mySat).Propagator).InitialState.Representation.ConvertTo(AgEOrbitStateType.eOrbitStateClassical)).SizeShape).PerigeeAltitude;
            double perigeeRound = Math.Round(perigee, 3);


            TestQuestion questionPerigee = new TestQuestion();
            questionPerigee.Objective = mySat.InstanceName + " Perigee Altitude Limit";
            questionPerigee.RequiredConstraint = requiredConstraint;
            questionPerigee.ConstraintType = "Satellite Constraint";

            questionPerigee.UsedConstraint = Convert.ToString(perigeeRound) + " km";

            if (mySat != null)
            {
                if ((perigee >= requiredConstraintTestValue))
                {
                    questionPerigee.Violations = "No Violations";
                }
                else
                {
                    questionPerigee.Violations = "Violated";
                    kanSatConstraintViolated = true;

                    ((IAgClassicalSizeShapeAltitude)keplerian.SizeShape).PerigeeAltitude = requiredConstraintValue;

                    //Limit apogee to be greater than or equal to perigee
                    if (Math.Round(apogee) < requiredConstraintValue)
                    {
                        ((IAgClassicalSizeShapeAltitude)keplerian.SizeShape).ApogeeAltitude = requiredConstraintValue;
                    }

                    // Propagate
                    ((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).InitialState.Representation.Assign(keplerian);
                    ((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).Propagate();
                }
            }
            m_questions.Add(questionPerigee);
        }

        //Check apogee constraints and change to maximum value if too high
        private void apogeeCheck(IAgStkObject mySat, String requiredConstraint, double requiredConstraintValue, double requiredConstraintTestValue)
        {
            m_root.UnitPreferences.SetCurrentUnit("Distance", "km");

            // Make sure it is set to altitude shape type
            IAgOrbitStateClassical keplerian;
            keplerian = ((IAgOrbitStateClassical)((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).InitialState.Representation.ConvertTo(AgEOrbitStateType.eOrbitStateClassical));
            keplerian.SizeShapeType = AgEClassicalSizeShape.eSizeShapeAltitude;
            ((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).InitialState.Representation.Assign(keplerian);

            double apogee = ((IAgClassicalSizeShapeAltitude)((IAgOrbitStateClassical)((IAgVePropagatorJ2Perturbation)
                ((IAgSatellite)mySat).Propagator).InitialState.Representation.ConvertTo(AgEOrbitStateType.eOrbitStateClassical)).SizeShape).ApogeeAltitude;
            double apogeeRound = Math.Round(apogee, 3);
            double perigee = ((IAgClassicalSizeShapeAltitude)((IAgOrbitStateClassical)((IAgVePropagatorJ2Perturbation)
                ((IAgSatellite)mySat).Propagator).InitialState.Representation.ConvertTo(AgEOrbitStateType.eOrbitStateClassical)).SizeShape).PerigeeAltitude;
            double perigeeRound = Math.Round(perigee, 3);


            // Check apogee
            TestQuestion questionApogee = new TestQuestion();
            questionApogee.Objective = mySat.InstanceName + " Apogee Altitude Limit";
            questionApogee.RequiredConstraint = requiredConstraint;
            questionApogee.ConstraintType = "Satellite Constraint";

            questionApogee.UsedConstraint = Convert.ToString(apogeeRound) + " km";

            if (mySat != null)
            {
                if (apogee <= requiredConstraintTestValue)
                {
                    questionApogee.Violations = "No Violations";
                }
                else
                {
                    questionApogee.Violations = "Violated";
                    kanSatConstraintViolated = true;

                    ((IAgClassicalSizeShapeAltitude)keplerian.SizeShape).ApogeeAltitude = requiredConstraintValue;

                    //Limit perigee to be less than or equal to apogee
                    if (Math.Round(perigee) > requiredConstraintValue)
                    {
                        ((IAgClassicalSizeShapeAltitude)keplerian.SizeShape).PerigeeAltitude = requiredConstraintValue;
                    }

                    // Propagate
                    ((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).InitialState.Representation.Assign(keplerian);
                    ((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).Propagate();

                }
            }
            m_questions.Add(questionApogee);
        }

        //Check inclination of satellite and change to upper or lower bound of allowed values if wrong
        private void IncCheck(IAgStkObject mySat, double lowerBound, double upperBound, string requiredConstraint)
        {
            IAgOrbitStateClassical keplerian;
            keplerian = ((IAgOrbitStateClassical)((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).InitialState.Representation.ConvertTo(AgEOrbitStateType.eOrbitStateClassical));
            keplerian.SizeShapeType = AgEClassicalSizeShape.eSizeShapeAltitude;
            ((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).InitialState.Representation.Assign(keplerian);
            //Pull orbital elements data provider
            IAgDataProviderGroup dpInfo1 = OLESS.DataProviders["Classical Elements"] as IAgDataProviderGroup;
            IAgDataPrvTimeVar dpInfo2 = dpInfo1.Group["ICRF"] as IAgDataPrvTimeVar;
            IAgDrResult resInfo = dpInfo2.ExecSingle("1 May 2020 00:00:00.000 ");

            //Pull inclination value to check launch vehicle constraint
            System.Array inc = resInfo.DataSets.GetDataSetByName("Inclination").GetValues();
            double incRound = Double.Parse(inc.GetValue(0).ToString());

            TestQuestion questionInc = new TestQuestion();
            questionInc.Objective = mySat.InstanceName + "Inclination Limits";
            questionInc.RequiredConstraint = "28<= inc <=60";
            questionInc.ConstraintType = "Satellite Constraint";
            questionInc.UsedConstraint = Convert.ToString(incRound) + " deg";

            if (incRound > upperBound)
            {
                questionInc.Violations = "Violated";

                ((IAgClassicalOrientation)keplerian.Orientation).Inclination = upperBound;

                ((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).InitialState.Representation.Assign(keplerian);
                ((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).Propagate();


            }
            else if (incRound < lowerBound)
            {
                questionInc.Violations = "Violated";

                ((IAgClassicalOrientation)keplerian.Orientation).Inclination = lowerBound;

                ((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).InitialState.Representation.Assign(keplerian);
                ((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).Propagate();

            }
            else
            {
                questionInc.Violations = "No Violations";

            }


            m_questions.Add(questionInc);
        }

        //Check Launch Vehicle Constraint and change apogee to maximum allowed for given inclination
        private void LVCheck(IAgStkObject mySat)
        {
            m_root.UnitPreferences.SetCurrentUnit("Distance", "km");

            // Make sure it is set to altitude shape type
            IAgOrbitStateClassical keplerian;
            keplerian = ((IAgOrbitStateClassical)((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).InitialState.Representation.ConvertTo(AgEOrbitStateType.eOrbitStateClassical));
            keplerian.SizeShapeType = AgEClassicalSizeShape.eSizeShapeAltitude;
            ((IAgVePropagatorJ2Perturbation)((IAgSatellite)mySat).Propagator).InitialState.Representation.Assign(keplerian);

            double apogee = ((IAgClassicalSizeShapeAltitude)((IAgOrbitStateClassical)((IAgVePropagatorJ2Perturbation)
                ((IAgSatellite)mySat).Propagator).InitialState.Representation.ConvertTo(AgEOrbitStateType.eOrbitStateClassical)).SizeShape).ApogeeAltitude;
            double apogeeRound = Math.Round(apogee, 3);
            double perigee = ((IAgClassicalSizeShapeAltitude)((IAgOrbitStateClassical)((IAgVePropagatorJ2Perturbation)
                ((IAgSatellite)mySat).Propagator).InitialState.Representation.ConvertTo(AgEOrbitStateType.eOrbitStateClassical)).SizeShape).PerigeeAltitude;
            double perigeeRound = Math.Round(perigee, 3);

            IAgDataProviderGroup dpInfo1 = OLESS.DataProviders["Classical Elements"] as IAgDataProviderGroup;
            IAgDataPrvTimeVar dpInfo2 = dpInfo1.Group["ICRF"] as IAgDataPrvTimeVar;
            IAgDrResult resInfo = dpInfo2.ExecSingle("1 May 2020 00:00:00.000 ");

            //Pull inclination value to check launch vehicle constraint
            System.Array inc = resInfo.DataSets.GetDataSetByName("Inclination").GetValues();
            double incRound = Double.Parse(inc.GetValue(0).ToString());


            }

        //Check Access Constraints
        private double AccessCheck(IAgStkObject fromObject, IAgStkObject toObject, string startTime, string stopTime)
        {
            

            Array values = getAccessChecksIndividualValues(fromObject, toObject, startTime, stopTime);

            double durationCovered = 0.0;
            double totalDurationCovered = 0;
            double totalVal = 0;


            if (values!= null && values.Length > 1  )
            {
                for (int i = 0; i < values.Length; i++)
                {
                    
                    totalVal += Convert.ToDouble(values.GetValue(i));

                    totalVal = Math.Round(totalVal, 3);

                    totalDurationCovered = totalVal;
                }

            }
            else
            {
                totalDurationCovered = 0;
            }


            // Check Access Constraint
            return totalDurationCovered;


        }

        private Array getAccessChecksIndividualValues(IAgStkObject fromObject, IAgStkObject toObject, string startTime, string stopTime)
        {
            Array values;

            m_root.UnitPreferences.SetCurrentUnit("Time", "min");
            m_root.UnitPreferences.SetCurrentUnit("DateFormat", "UTCG");

            IAgStkAccess access = fromObject.GetAccessToObject(toObject) as IAgStkAccess;
            access.ComputeAccess();
            IAgDataPrvInterval dp = access.DataProviders["Access Data"] as IAgDataPrvInterval;
            Array elems = new object[]
                          {
                  "Duration"
                          };
            // ExecElements expects the third parameter to be a one dimensional array of element names 
            IAgDrResult resInfo2 = dp.ExecElements(startTime, stopTime, ref elems);

            if (resInfo2.DataSets.Count > 0)
            {
                IAgDrDataSet totalDuration = resInfo2.DataSets.GetDataSetByName("Duration") as IAgDrDataSet;

                values = totalDuration.GetValues();
            }
            else
            {
                values = null;
            }

            return values;

        }

        private Array getAccessChecksStartValues(IAgStkObject fromObject, IAgStkObject toObject, string startTime, string stopTime)
        {
            Array values;
            Array values2;
            Array values1;
            Array values4;

            m_root.UnitPreferences.SetCurrentUnit("Time", "min");
            m_root.UnitPreferences.SetCurrentUnit("DateFormat", "UTCG");

            IAgStkAccess access = fromObject.GetAccessToObject(toObject) as IAgStkAccess;
            IAgDataPrvInterval dp = access.DataProviders["Access Data"] as IAgDataPrvInterval;
            Array elems = new object[]
                          {
                  "Start Time"
                          };
            // ExecElements expects the third parameter to be a one dimensional array of element names 
            IAgDrResult resInfo2 = dp.ExecElements(startTime, stopTime, ref elems);

            if (resInfo2.DataSets.Count > 0)
            {
                IAgDrDataSet startTime1 = resInfo2.DataSets.GetDataSetByName("Start Time") as IAgDrDataSet;
                values1 = startTime1.GetValues();
            }

            else
            {
                values1 = null;
            }

                    return values1;

        }

        private void sensorFOV(IAgStkObject mySensor, String requiredConstraint, double requiredConstraintValue)
        {
            m_root.UnitPreferences.SetCurrentUnit("Angle", "deg");

            TestQuestion question = new TestQuestion();
            question.Objective = "Imaging_Camera Cone Angle";
            question.RequiredConstraint = requiredConstraint;
            question.ConstraintType = "Fixed Constraint";

            if (mySensor != null)
            {
                if (((IAgSensor)mySensor).PatternType == AgESnPattern.eSnSimpleConic)
                {
                    IAgSnSimpleConicPattern pattern = ((IAgSensor)mySensor).Pattern as IAgSnSimpleConicPattern;
                    question.UsedConstraint = Convert.ToString(Math.Round(pattern.ConeAngle)) + " deg";
                    if (Math.Round(pattern.ConeAngle) == requiredConstraintValue)
                    {
                        question.Violations = "No Violations";
                        fixedConstraintViolated = false;
                    }
                    else
                    {

                        pattern.ConeAngle = requiredConstraintValue;
                        question.Violations = "Violated";
                        fixedConstraintViolated = true;

                    }
                }
            }
            m_questions.Add(question);
        }


        public List<TestQuestion> Results()
        {
            reset();

            OLESS = stkObjectInScenario("OLESS", "Satellite");

            //Pull orbital elements data provider
            IAgDataProviderGroup dpInfo1 = OLESS.DataProviders["Classical Elements"] as IAgDataProviderGroup;
            IAgDataPrvTimeVar dpInfo2 = dpInfo1.Group["ICRF"] as IAgDataPrvTimeVar;
            IAgDrResult resInfo = dpInfo2.ExecSingle("1 May 2020 00:00:00.000 ");

            //Pull inclination value to check launch vehicle constraint
            System.Array inc = resInfo.DataSets.GetDataSetByName("Inclination").GetValues();
           


            //get object instances 
            Amsterdam = stkObjectInScenario("Amsterdam", "Target");
            Ascension = stkObjectInScenario("Ascension", "Target");
            Easter = stkObjectInScenario("Easter", "Target");
            Seychelles = stkObjectInScenario("Seychelles", "Target");
            Shanghai = stkObjectInScenario("Shanghai", "Target");
            Shemya = stkObjectInScenario("Shemya", "Target");
            Sundarbans = stkObjectInScenario("Sundarbans", "Target");
            Wake = stkObjectInScenario("Wake", "Target");
            SOF = stkObjectInScenario("SOF", "Facility");
            WideView_120 = stkSensorExists("WideView_120", OLESS);
            WideView_130 = stkSensorExists("WideView_130", OLESS);
            WideView_140 = stkSensorExists("WideView_140", OLESS);

            //check to make sure objects are not null
            objectCheck();
            m_root.ExecuteCommand("SetConstraint */Facility/SOF Duration Min 90");
            m_root.ExecuteCommand("SetConstraint */Target/Amsterdam Duration Min 90");
            m_root.ExecuteCommand("SetConstraint */Target/Ascension Duration Min 90");
            m_root.ExecuteCommand("SetConstraint */Target/Easter Duration Min 90");
            m_root.ExecuteCommand("SetConstraint */Target/Seychelles Duration Min 90");
            m_root.ExecuteCommand("SetConstraint */Target/Shanghai Duration Min 90");
            m_root.ExecuteCommand("SetConstraint */Target/Shemya Duration Min 90");
            m_root.ExecuteCommand("SetConstraint */Target/Sundarbans Duration Min 90");
            m_root.ExecuteCommand("SetConstraint */Target/Wake Duration Min 90");

            //check fixed constraints
            startTime();
            stopTime();
            propagatorConstraint(OLESS);
            timeStepConstraint(OLESS);
            sensorFOV(WideView_120, "FOV = 60 deg", 60.0);
            sensorFOV(WideView_130, "FOV = 65 deg", 65.0);
            sensorFOV(WideView_140, "FOV = 70 deg", 70.0);

            //Check spacecraft Operational Constraints
            perigeeCheck(OLESS, ">= 150 km", 150, 149.9);
            apogeeCheck(OLESS, "<= 500 km", 500, 500.1);
            IncCheck(OLESS, 28.0, 60.0, "28<= inc <=60");

            //Get orbital elements for satellite
            OLESSSatSatOrbitalElements = new List<double>();
            OLESSSatSatOrbitalElements = GetOrbitalElements(OLESS);

            //check launch vehicle constraint
            //LVCheck(OLESS);


            //Check constraints and access for each ground location. Check size and location of area targets prior to calculating each access
            facLatCheck(SOF, "38.8522 deg", 38.8522);
            facLonCheck(SOF, "-76.9368 deg", -76.9368);
            facAltCheck(SOF, "90 meters", 90);

            wideViewList140 = getAccessChecksIndividualValues(WideView_140, SOF, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00");
            wideView130 = getAccessChecksIndividualValues(WideView_130, SOF, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00");
            wideView120 = getAccessChecksIndividualValues(WideView_120, SOF, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00");
            satelliteAccess = getAccessChecksIndividualValues(OLESS, SOF, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00");
            FirstStartTime = getAccessChecksStartValues(WideView_140, SOF, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00");

            ATLatCheck(Amsterdam, "52.3814 deg", 52.3814);
            ATLonCheck(Amsterdam, "4.94167 deg", 4.94167);
            ATAltCheck(Amsterdam, "0", 0.0);
            totalCoverage[0] = AccessCheck(WideView_140, Amsterdam, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00");
            totalCoverage[1] = AccessCheck(WideView_130, Amsterdam, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00");
            totalCoverage[2] = AccessCheck(WideView_120, Amsterdam, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00");

            ATLatCheck(Ascension, "-7.96667", -7.96667);
            ATLonCheck(Ascension, "-14.4133", -14.4133);
            ATAltCheck(Ascension, "0", 0.0);
            totalCoverage[3] = AccessCheck(WideView_140, Ascension, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00");
            totalCoverage[4] = AccessCheck(WideView_130, Ascension, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00");
            totalCoverage[5] = AccessCheck(WideView_120, Ascension, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00");

            ATLatCheck(Easter, "-27.1542°; ", -27.1542);
            ATLonCheck(Easter, "-109.44 deg", -109.44);
            ATAltCheck(Easter, "0", 0.0);
            totalCoverage[6] = AccessCheck(WideView_140, Easter, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00");
            totalCoverage[7] = AccessCheck(WideView_130, Easter, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00");
            totalCoverage[8] = AccessCheck(WideView_120, Easter, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00");

            ATLatCheck(Seychelles, "-4.625", -4.625);
            ATLonCheck(Seychelles, "55.4667deg", 55.4667);
            ATAltCheck(Seychelles, "0", 0.0);
            totalCoverage[9] = AccessCheck(WideView_140, Seychelles, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00");
            totalCoverage[10] = AccessCheck(WideView_130, Seychelles, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00");
            totalCoverage[11] = AccessCheck(WideView_120, Seychelles, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00");

            ATLatCheck(Shanghai, "31.3014 deg", 31.3014);
            ATLonCheck(Shanghai, "121.751 deg", 121.751);
            ATAltCheck(Shanghai, "0", 0.0);
            totalCoverage[12] = AccessCheck(WideView_140, Shanghai, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00");
            totalCoverage[13] = AccessCheck(WideView_130, Shanghai, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00");
            totalCoverage[14] = AccessCheck(WideView_120, Shanghai, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00");

            ATLatCheck(Shemya, "52.7289", 52.7289);
            ATLonCheck(Shemya, "174.072 deg", 174.072);
            ATAltCheck(Shemya, "0", 0.0);
            totalCoverage[15] = AccessCheck(WideView_140, Shemya, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00.");
            totalCoverage[16] = AccessCheck(WideView_130, Shemya, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00.");
            totalCoverage[17] = AccessCheck(WideView_120, Shemya, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00.");

            ATLatCheck(Sundarbans, "21.8783 deg", 21.8783);
            ATLonCheck(Sundarbans, "89.0339 deg", 89.0339);
            ATAltCheck(Sundarbans, "0", 0.0);
            totalCoverage[18] = AccessCheck(WideView_140, Sundarbans, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00.");
            totalCoverage[19] = AccessCheck(WideView_130, Sundarbans, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00.");
            totalCoverage[20] = AccessCheck(WideView_120, Sundarbans, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00.");

            ATLatCheck(Wake, "19.2972 deg", 19.2972);
            ATLonCheck(Wake, "166.626 deg", 166.626);
            ATAltCheck(Wake, "0", 0.0);
            totalCoverage[21] = AccessCheck(WideView_140, Wake, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00.");
            totalCoverage[22] = AccessCheck(WideView_130, Wake, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00.");
            totalCoverage[23] = AccessCheck(WideView_120, Wake, "1 May 2020 00:00:00.000 ", "8 May 2020 00:00:00.");

            return m_questions;
        }

    }


}
