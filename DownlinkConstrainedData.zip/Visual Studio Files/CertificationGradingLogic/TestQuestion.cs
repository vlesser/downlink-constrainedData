﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CertificationGradingLogic
{
    public class TestQuestion
    {
        
        public string Objective { get; set; }
        public string UsedConstraint { get; set; }
        public string RequiredConstraint { get; set; }
        public string Violations { get; set; }
        public string ConstraintType { get; set; }
    }
}
