﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CertificationGradingLogic
{
    public class TimelineComponent
    {
        public string ComponentName { get; set; }
        public string DisplayName { get; set; }
        public string Path { get; set; }
        public string Type { get; set; }
    }
}
