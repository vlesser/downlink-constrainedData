﻿namespace STKCertificationTestGrader
{
    partial class CertTestViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CertTestViewer));
            this.dgvTestResults = new System.Windows.Forms.DataGridView();
            this.btnLoadScenario = new System.Windows.Forms.Button();
            this.txtScenarioPath = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnGradeTest = new System.Windows.Forms.Button();
            this.opnFileSTK = new System.Windows.Forms.OpenFileDialog();
            this.opnFileExcel = new System.Windows.Forms.OpenFileDialog();
            this.label2 = new System.Windows.Forms.Label();
            this.lblResults = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.durResults = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.penaltyVal = new System.Windows.Forms.Label();
            this.errorLbl = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtExcelPath = new System.Windows.Forms.TextBox();
            this.btnLoadExcelSheet = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTestResults)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvTestResults
            // 
            this.dgvTestResults.AllowUserToAddRows = false;
            this.dgvTestResults.AllowUserToDeleteRows = false;
            this.dgvTestResults.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvTestResults.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTestResults.Location = new System.Drawing.Point(29, 110);
            this.dgvTestResults.Name = "dgvTestResults";
            this.dgvTestResults.ReadOnly = true;
            this.dgvTestResults.RowHeadersVisible = false;
            this.dgvTestResults.Size = new System.Drawing.Size(565, 425);
            this.dgvTestResults.TabIndex = 0;
            // 
            // btnLoadScenario
            // 
            this.btnLoadScenario.Enabled = false;
            this.btnLoadScenario.Location = new System.Drawing.Point(567, 70);
            this.btnLoadScenario.Name = "btnLoadScenario";
            this.btnLoadScenario.Size = new System.Drawing.Size(27, 26);
            this.btnLoadScenario.TabIndex = 1;
            this.btnLoadScenario.Text = "...";
            this.btnLoadScenario.UseVisualStyleBackColor = true;
            this.btnLoadScenario.Click += new System.EventHandler(this.btnLoadScenario_Click);
            // 
            // txtScenarioPath
            // 
            this.txtScenarioPath.Enabled = false;
            this.txtScenarioPath.Location = new System.Drawing.Point(29, 74);
            this.txtScenarioPath.Name = "txtScenarioPath";
            this.txtScenarioPath.ReadOnly = true;
            this.txtScenarioPath.Size = new System.Drawing.Size(536, 20);
            this.txtScenarioPath.TabIndex = 2;
            this.txtScenarioPath.TextChanged += new System.EventHandler(this.txtScenarioPath_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(26, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(202, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Load STK Scenario / VDF / Zip";
            // 
            // btnGradeTest
            // 
            this.btnGradeTest.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnGradeTest.Enabled = false;
            this.btnGradeTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGradeTest.Location = new System.Drawing.Point(454, 562);
            this.btnGradeTest.Name = "btnGradeTest";
            this.btnGradeTest.Size = new System.Drawing.Size(140, 37);
            this.btnGradeTest.TabIndex = 5;
            this.btnGradeTest.Text = "Grade Test";
            this.btnGradeTest.UseVisualStyleBackColor = true;
            this.btnGradeTest.Click += new System.EventHandler(this.btnGradeTest_Click);
            // 
            // opnFileSTK
            // 
            this.opnFileSTK.FileName = "openFileDialog1";
            // 
            // opnFileExcel
            // 
            this.opnFileExcel.FileName = "openFileDialog2";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(257, 562);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "Penalty:";
            // 
            // lblResults
            // 
            this.lblResults.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblResults.AutoSize = true;
            this.lblResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResults.Location = new System.Drawing.Point(355, 592);
            this.lblResults.Name = "lblResults";
            this.lblResults.Size = new System.Drawing.Size(13, 17);
            this.lblResults.TabIndex = 7;
            this.lblResults.Text = "-";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(29, 562);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "Percent Covered:";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(29, 592);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 17);
            this.label4.TabIndex = 9;
            this.label4.Text = "Duration Covered:";
            // 
            // durResults
            // 
            this.durResults.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.durResults.AutoSize = true;
            this.durResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.durResults.Location = new System.Drawing.Point(153, 592);
            this.durResults.Name = "durResults";
            this.durResults.Size = new System.Drawing.Size(17, 17);
            this.durResults.TabIndex = 11;
            this.durResults.Text = "- ";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(257, 592);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 17);
            this.label5.TabIndex = 12;
            this.label5.Text = "Final Score:";
            // 
            // penaltyVal
            // 
            this.penaltyVal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.penaltyVal.AutoSize = true;
            this.penaltyVal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.penaltyVal.Location = new System.Drawing.Point(355, 562);
            this.penaltyVal.Name = "penaltyVal";
            this.penaltyVal.Size = new System.Drawing.Size(13, 17);
            this.penaltyVal.TabIndex = 13;
            this.penaltyVal.Text = "-";
            // 
            // errorLbl
            // 
            this.errorLbl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.errorLbl.AutoSize = true;
            this.errorLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorLbl.ForeColor = System.Drawing.Color.Black;
            this.errorLbl.Location = new System.Drawing.Point(257, 613);
            this.errorLbl.Name = "errorLbl";
            this.errorLbl.Size = new System.Drawing.Size(13, 17);
            this.errorLbl.TabIndex = 14;
            this.errorLbl.Text = "-";
            this.errorLbl.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(26, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(173, 17);
            this.label6.TabIndex = 17;
            this.label6.Text = "Load Excel Solution Sheet";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // txtExcelPath
            // 
            this.txtExcelPath.Location = new System.Drawing.Point(29, 29);
            this.txtExcelPath.Name = "txtExcelPath";
            this.txtExcelPath.ReadOnly = true;
            this.txtExcelPath.Size = new System.Drawing.Size(536, 20);
            this.txtExcelPath.TabIndex = 16;
            this.txtExcelPath.TextChanged += new System.EventHandler(this.txtExcelPath_TextChanged);
            // 
            // btnLoadExcelSheet
            // 
            this.btnLoadExcelSheet.Location = new System.Drawing.Point(567, 25);
            this.btnLoadExcelSheet.Name = "btnLoadExcelSheet";
            this.btnLoadExcelSheet.Size = new System.Drawing.Size(27, 26);
            this.btnLoadExcelSheet.TabIndex = 15;
            this.btnLoadExcelSheet.Text = "...";
            this.btnLoadExcelSheet.UseVisualStyleBackColor = true;
            this.btnLoadExcelSheet.Click += new System.EventHandler(this.btnLoadExcelSheet_Click);
            // 
            // CertTestViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(620, 637);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtExcelPath);
            this.Controls.Add(this.btnLoadExcelSheet);
            this.Controls.Add(this.errorLbl);
            this.Controls.Add(this.penaltyVal);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.durResults);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblResults);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnGradeTest);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtScenarioPath);
            this.Controls.Add(this.btnLoadScenario);
            this.Controls.Add(this.dgvTestResults);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CertTestViewer";
            this.Text = "Stellar Xplorer Test Grader";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTestResults)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvTestResults;
        private System.Windows.Forms.Button btnLoadScenario;
        private System.Windows.Forms.TextBox txtScenarioPath;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnGradeTest;
        private System.Windows.Forms.OpenFileDialog opnFileSTK;
        private System.Windows.Forms.OpenFileDialog opnFileExcel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblResults;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        // private System.Windows.Forms.Label perResults;
        private System.Windows.Forms.Label durResults;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label penaltyVal;
        private System.Windows.Forms.Label errorLbl;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtExcelPath;
        private System.Windows.Forms.Button btnLoadExcelSheet;
    }
}