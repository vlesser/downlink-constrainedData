﻿using CertificationGradingLogic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using Microsoft.Office.Core;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;

namespace STKCertificationTestGrader
{
    public partial class CertTestViewer : Form
    {
        StkGrading m_stkGrader;

        private static Excel.Workbook MySolutionBook = null;
        private static Excel.Application MySolutionApp = null;
        private static Excel.Worksheet MySolutionSheet = null;

        private static Excel.Workbook MyBook = null;
        private static Excel.Application MyApp = null;
        private static Excel.Worksheet MySheet2 = null;

        private static Excel.Workbook MyBook2 = null;
        private static Excel.Application MyApp2 = null;
        private static Excel.Worksheet MySheet3 = null;

        private static Excel.Worksheet MySheet1 = null;

        private string teamNumber;
        private string orgName;

        public CertTestViewer()
        {
            InitializeComponent();
        }

        private void btnLoadScenario_Click(object sender, EventArgs e)
        {
            opnFileSTK.Filter = "Supported Types (*.sc, *.VDF, *.zip) | *.sc; *.VDF; *.zip;  | STK Scenario |*.sc| VDF |*.vdf| Zip |*.zip";
            opnFileSTK.FilterIndex = 1;
            opnFileSTK.Multiselect = false;

            if (opnFileSTK.ShowDialog() == DialogResult.OK)
            {
                txtScenarioPath.Text = opnFileSTK.FileName;
                btnGradeTest.Enabled = true;

                m_stkGrader = new StkGrading(opnFileSTK.FileName);

                // Get from Solution Sheet

                MySolutionBook.Close();
                MySolutionApp.Quit();
            }
        }

        private string checkIfNullStr(Excel.Range cell, bool closeSTK)
        {
            string store;

            if (cell.Value != null)
            {
                store = cell.Value.ToString();
            }
            else
            {
                store = "";
                if (closeSTK)
                {
                    MessageBox.Show("Solution sheet incomplete. Row " + cell.Row + ", Column " + cell.Column + " is empty. This application will close.", "Null Value");
                    Application.Exit();
                }

            }

            return store;
        }

        private double checkIfNullNum(Excel.Range cell, bool closeSTK)
        {
            double store;

            if (cell.Value != null)
            {
                store = cell.Value;
            }
            else
            {
                store = 0;
                if (closeSTK)
                {
                    MessageBox.Show("Solution sheet incomplete. Row " + cell.Row + ", Column " + cell.Column + " is empty. This application will close.", "Null Value");
                    Application.Exit();
                }
            }

            return store;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

        }

        private void btnGradeTest_Click(object sender, EventArgs e)
        {

            double finalScore = 0;
            double duration = 0;
            double penalty = 0;
            string errorMessage = "";

            dgvTestResults.DataSource = null;
            List<TestQuestion> gradedQs = m_stkGrader.Results();
            dgvTestResults.DataSource = gradedQs;
            dgvTestResults.ColumnHeadersDefaultCellStyle.Font = new Font("Tahoma", 10F, FontStyle.Bold);
            foreach (DataGridViewColumn column in dgvTestResults.Columns)
            {
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            }

            foreach (DataGridViewRow row in dgvTestResults.Rows)
            {
                if (Convert.ToString(row.Cells["Violations"].Value) == "No Violations")
                {
                    row.Cells["Violations"].Style.BackColor = Color.LimeGreen;

                }
                else if (Convert.ToString(row.Cells["Violations"].Value) == "Violated")
                {
                    row.Cells["Violations"].Style.BackColor = Color.Red;
                }


                // finalScore = m_stkGrader.pointCalculator();
                duration = 0;
                errorMessage = m_stkGrader.message;
            }

            lblResults.Text = finalScore.ToString() + " pts";
            durResults.Text = "N/A"; // duration.ToString() + " min";
            penaltyVal.Text = penalty.ToString() + " pts";
            errorLbl.Text = errorMessage;
            errorLbl.ForeColor = label1.ForeColor = Color.Red;
            int positionName = opnFileSTK.FileName.LastIndexOf('\\');
            string scenarioName = opnFileSTK.FileName.Substring(positionName + 1);
            string scenarioPath = opnFileSTK.FileName.Substring(0, positionName);
            string scenarioNameNoFile = scenarioName.Substring(0, scenarioName.LastIndexOf('.'));


            string[] lines = { "Filename: " + scenarioName, "Final Score: " + finalScore.ToString(), "Penalty: " + penalty.ToString() };

            // Creating a string of all of the fixed constraint violations for the report
            List<TestQuestion> fixedConstraints = gradedQs.FindAll(FixedConstraints);
            string[] listFixedCons = new string[fixedConstraints.Count + 1];
            Debug.WriteLine("fixedConstraints " + fixedConstraints.Count);
            listFixedCons[0] = "Fixed Constraints Violations: ";
            for (int i = 0; i < listFixedCons.Length - 1; i++)
            {
                listFixedCons[i + 1] = fixedConstraints[i].Objective;
            }

            // Creating a string of all of the kanSat constraint violations for the report
            List<TestQuestion> satelliteConstraints = gradedQs.FindAll(SatelliteConstraints);
            string[] listSatelliteCons = new string[satelliteConstraints.Count + 1];
            listSatelliteCons[0] = "Satellite Constraints Violations: ";
            for (int i = 0; i < listSatelliteCons.Length - 1; i++)
            {
                listSatelliteCons[i + 1] = satelliteConstraints[i].Objective;
            }

            // Creating a string of all of the launch vehicle constraint violations for the report
            List<TestQuestion> launchConstraints = gradedQs.FindAll(LaunchVehicleConstraints);
            string[] listLaunchCons = new string[launchConstraints.Count + 1];
            listLaunchCons[0] = "Launch Vehicle Constraints Violations: ";
            for (int i = 0; i < listLaunchCons.Length - 1; i++)
            {
                listLaunchCons[i + 1] = launchConstraints[i].Objective;
            }



            // Prompt user if it is ok to save and close all running processes of Excel
            DialogResult dialogResult = MessageBox.Show("This application will close all running background processes of Excel. Continue?", "Warning", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.No)
            {
                Application.Exit();
            }
            else if (dialogResult == DialogResult.Yes)
            {

                // Close running background processes of Excel
                try
                {
                    foreach (Process proc in Process.GetProcessesByName("Microsoft Excel"))
                    {
                        proc.Kill();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }


                // Open Excel Tempalte
                MyApp = new Excel.Application();
                MyApp.Visible = false;
                try
                {
                    MyBook = MyApp.Workbooks.Open(System.IO.Path.GetFullPath("STLX06.xlsx"));
                }
                catch
                {
                    MyBook = MyApp.Workbooks.Open(System.IO.Path.GetFullPath("STLX06.xls"));
                }

                MySheet1 = (Excel.Worksheet)MyBook.Sheets[1];
                MySheet2 = (Excel.Worksheet)MyBook.Sheets[2];
                MySheet3 = (Excel.Worksheet)MyBook.Sheets[3];

                //Writeorbital elements
                MySheet1.Cells[11, 3] = m_stkGrader.OLESSSatSatOrbitalElements[0].ToString();
                MySheet1.Cells[12, 3] = m_stkGrader.OLESSSatSatOrbitalElements[1].ToString();
                MySheet1.Cells[13, 3] = m_stkGrader.OLESSSatSatOrbitalElements[2].ToString();
                MySheet1.Cells[14, 3] = m_stkGrader.OLESSSatSatOrbitalElements[3].ToString();
                MySheet1.Cells[15, 3] = m_stkGrader.OLESSSatSatOrbitalElements[4].ToString();
                MySheet1.Cells[16, 3] = m_stkGrader.OLESSSatSatOrbitalElements[5].ToString();

                // Fixed Constraint Violations?
                if (fixedConstraints.Count > 0)
                {
                    MySheet1.Cells[62, 3] = "Yes";
                }
                else
                {
                    MySheet1.Cells[62, 3] = "No";
                }

                // Satellite Constraint Violations?
                if (satelliteConstraints.Count > 0)
                {
                    MySheet1.Cells[63, 3] = "Yes";
                }
                else
                {
                    MySheet1.Cells[63, 3] = "No";
                }

                // Launch Vehicle Constraint Violations?
                if (launchConstraints.Count > 0)
                {
                    MySheet1.Cells[64, 3] = "Yes";
                }
                else
                {
                    MySheet1.Cells[64, 3] = "No";
                }

                //MySheet = (Excel.Worksheet)MyBook.Sheets[1]; // Explicit cast is not required here
                double allCoverage = 0.0;
                int coverageCount = 0;

                int rowNumber = 1;

                // Populationg sensor to facility values
                for (int i = 0; i < m_stkGrader.totalCoverage.Length; i += 3)
                {

                    MySheet2.Cells[(rowNumber + 2), 2] = m_stkGrader.totalCoverage[i];
                    MySheet2.Cells[(rowNumber + 2), 3] = m_stkGrader.totalCoverage[i + 1];
                    MySheet2.Cells[(rowNumber + 2), 4] = m_stkGrader.totalCoverage[i + 2];
                    rowNumber += 1;
                }


                for (int i = 0; i < m_stkGrader.wideViewList140.Length; i++)
                {
                    MySheet3.Cells[i + 3, 4] = m_stkGrader.wideViewList140.GetValue(i);
                }

                for (int i = 0; i < m_stkGrader.wideView130.Length; i++)
                {
                    MySheet3.Cells[i + 3, 5] = m_stkGrader.wideView130.GetValue(i);
                }

                for (int i = 0; i < m_stkGrader.wideView120.Length; i++)
                {
                    MySheet3.Cells[i + 3, 6] = m_stkGrader.wideView120.GetValue(i);
                }

                for(int i = 0; i < m_stkGrader.wideView120.Length; i++)
                {
                    MySheet3.Cells[i + 3, 1] = i;
                }
                for (int i = 0; i < m_stkGrader.FirstStartTime.Length; i++)
                {
                    MySheet3.Cells[i + 3, 2] = m_stkGrader.FirstStartTime.GetValue(i);
                }
                for (int i = 0; i < m_stkGrader.satelliteAccess.Length; i++)
                {
                    MySheet3.Cells[i + 3, 3] = m_stkGrader.satelliteAccess.GetValue(i);
                }



                MyBook.SaveAs(scenarioPath + "\\" + scenarioNameNoFile + " Scoring Sheet.xlsx");
                MyBook.Close();
                MyApp.Quit();
            }
        }

        private void txtScenarioPath_TextChanged(object sender, EventArgs e)
        {

        }

        // Search questions returns true if the question is violated Fixed Constraint
        private static bool FixedConstraints(TestQuestion question)
        {
            if (question.ConstraintType == "Fixed Constraint" && question.Violations == "Violated")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // Search questions returns true if the question is violated Satellite Constraint
        private static bool SatelliteConstraints(TestQuestion question)
        {
            if (question.ConstraintType == "Satellite Constraint" && question.Violations == "Violated")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // Search questions returns true if the question is violated Launch Vehicle Constraint
        private static bool LaunchVehicleConstraints(TestQuestion question)
        {
            if (question.ConstraintType == "Launch Vehicle Constraint" && question.Violations == "Violated")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void txtExcelPath_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLoadExcelSheet_Click(object sender, EventArgs e)
        {
            // opnFileSTK.Filter = "Supported Types (*.sc, *.VDF, *.zip) | *.sc; *.VDF; *.zip;  | STK Scenario |*.sc| VDF |*.vdf| Zip |*.zip";
            // opnFileSTK.FilterIndex = 1;
            opnFileExcel.Multiselect = false;

            if (opnFileExcel.ShowDialog() == DialogResult.OK)
            {
                txtExcelPath.Text = opnFileExcel.FileName;
                btnLoadScenario.Enabled = true;
                // Open Excel Solution Sheet
                MySolutionApp = new Excel.Application();
                MySolutionApp.Visible = false;
                MySolutionBook = MySolutionApp.Workbooks.Open(txtExcelPath.Text);
                MySolutionSheet = (Excel.Worksheet)MySolutionBook.Sheets[4]; // Explicit cast is not required here
                Excel.Range xlRange = MySolutionSheet.UsedRange;


            }
            // If the field is not filled out, disable the field to specify a scenario
            else
            {
                txtScenarioPath.Enabled = false;
                btnLoadScenario.Enabled = false;
            }
        }
    }
}
